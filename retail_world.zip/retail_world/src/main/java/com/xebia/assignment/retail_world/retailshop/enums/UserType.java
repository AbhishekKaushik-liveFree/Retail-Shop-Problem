package com.xebia.assignment.retail_world.retailshop.enums;

public enum UserType {

}
