package com.xebia.assignment.retail_world.shopper.core;

public enum UserType {
	EMPLOYEE,
	AFFILIATE,
	SIMPLE
}
