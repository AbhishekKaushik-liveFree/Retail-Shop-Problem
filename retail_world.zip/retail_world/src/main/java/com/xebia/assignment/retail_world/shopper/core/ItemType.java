package com.xebia.assignment.retail_world.shopper.core;

/*
 * The category of product/item
 * 
 */
public enum ItemType {
	GROCERY,
	OTHER,
}
